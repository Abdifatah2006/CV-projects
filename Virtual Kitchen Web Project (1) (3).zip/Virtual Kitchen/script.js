document
  .getElementById("contactForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    let email = document.getElementById("email").value;
    let confirmEmail = document.getElementById("confirmEmail").value;
    let appointment = document.getElementById("appointment").value;
    let today = new Date().toISOString().split("T")[0];

    if (!email.endsWith("@aston.ac.uk")) {
      alert("Please enter a valid Aston University email.");
      return;
    }

    if (email !== confirmEmail) {
      alert("Emails do not match.");
      return;
    }

    if (appointment <= today) {
      alert("Please select a future date.");
      return;
    }

    alert("Form submitted successfully!");
  });
